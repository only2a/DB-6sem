

sp_configure 'clr enabled', 1;
RECONFIGURE;

select * from sys.assemblies;

CREATE ASSEMBLY CopyFileAssembly FROM 'D:\3C_2S\��\labs\lab3\stored-proc\stored-proc\bin\Debug\stored-proc.dll' WITH PERMISSION_SET = UNSAFE;

 DROP ASSEMBLY CopyFileAssembly

ALTER DATABASE master SET TRUSTWORTHY ON

drop procedure CopyFileProc

CREATE PROCEDURE CopyFileProc
    @sourcePath NVARCHAR(MAX),
    @destinationPath NVARCHAR(MAX)
AS EXTERNAL NAME CopyFileAssembly.[StoredProcedures].CopyFileProc;
GO

EXEC CopyFileProc 'D:\3C_2S\��\labs\lab3\file1.txt', 'D:\3C_2S\��\labs\lab3\test\file2.txt';

SELECT * FROM sys.types;

CREATE TYPE UserCredentials EXTERNAL NAME CopyFileAssembly.[stored_proc.UserCredentials];

drop type UserCredentials

drop table SocialMediaCredentials

declare @a dbo.UserCredentials;

set @a = 'aaaa,bbbbb';

print @a.Username;


-----------------------------------------------------------
create  type Task
EXTERNAL NAME  CopyFileAssembly.[SqlUserDefinedType1];

declare @task as Task
set @task ='Task1 Description1 2023-01-01 Petrov'
print @task.ToString()